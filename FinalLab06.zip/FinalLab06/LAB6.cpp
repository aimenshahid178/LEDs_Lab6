#include "Arduino.h"
#include "LAB6.h"


myClass::myClass(int a, int b, int c, int d, int e, int f, int g, int h){

 a = pin1;
 b = pin2;
 c = pin3;
 d = pin4;
 e = pin5;
 f = pin6;
 g = pin7;
 h = pin8;
  
  pinMode(pin1,OUTPUT);
  pinMode(pin2,OUTPUT);
  pinMode(pin3,OUTPUT);
  pinMode(pin4,OUTPUT);
  pinMode(pin5,OUTPUT);
  pinMode(pin6,OUTPUT);
  pinMode(pin7,OUTPUT);
  pinMode(pin8,OUTPUT);
  
}

void myClass::begin(){

  
  digitalWrite(pin1,HIGH);
  digitalWrite(pin2,HIGH);
  digitalWrite(pin3,HIGH);
  digitalWrite(pin4,HIGH);
  digitalWrite(pin5,HIGH);
  digitalWrite(pin6,HIGH);
  digitalWrite(pin7,HIGH);
  digitalWrite(pin8,HIGH);
  
}
  


int myClass:: upCount(){
    int pins[8] = {};
  for (int i = 0; i< 256; i++)
  {
    for(int j = 0; j<9; j++)
  {
    if(bitRead(i, j)==1)
      {digitalWrite(pins[j], HIGH);
     }
     else
      {digitalWrite(pins[j], LOW); 
      }
  }
    delay(1000);
  }

}



int myClass:: downCount(){
  int pins[8] = {};
  for (int i = 0; i> 256; i--)
  {
    for(int j = 0; j>9; j--)
  {
    if(bitRead(i, j)==1)
      {digitalWrite(pins[j], HIGH);
     }
     else
      {digitalWrite(pins[j], LOW); 
     }
  }
    delay(1000);
  }  

}
int myClass::shiftRight(){
 int val[]={1,2,4,8,16,32,64,128};
  int pins[8] = {pin1,pin2,pin3,pin4,pin5,pin6,pin7,pin8};
  for (int i = 0; i< 32; i++)
  {
      for(int j = 0; j<8; j++)
  
      if(bitRead(val [i],j)==1)
      {
      digitalWrite(pins[j], HIGH);
      }
      else
      {
      digitalWrite(pins[j],LOW);
      }
     delay(250);
  }
}
int myClass:: shiftLeft(){
    int val[]={1,2,4,8,16,32,64,128};
    int pins[8] = {pin1,pin2,pin3,pin4,pin5,pin6,pin7,pin8};
  for (int i = 32; i>0; i--)
  {
      for(int j = 8; j>0; j--)
  
      if(bitRead(i,j)==1)
      {
      digitalWrite(pins[j], HIGH);
      }
      else
      {
      digitalWrite(pins[j],LOW);
      }
     delay(250);
  

}

}


void myClass::allOff(){

 
  digitalWrite(pin1,LOW);
  digitalWrite(pin2,LOW);
  digitalWrite(pin3,LOW);
  digitalWrite(pin4,LOW);
  digitalWrite(pin5,LOW);
  digitalWrite(pin6,LOW);
  digitalWrite(pin7,LOW);
  digitalWrite(pin8,LOW);

}
