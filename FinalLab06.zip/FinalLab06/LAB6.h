#ifndef LAB6_h
#define LAB6_h
#include "Arduino.h"

class myClass {
  
  public:
    myClass::myClass(int a, int b, int c, int d, int e, int f, int g, int h);
    void begin();
    int upCount();
    int downCount();
    int shiftRight();
    int shiftLeft();
    void allOff();

  private:
    int pin1;
    int pin2;
    int pin3;
    int pin4;
    int pin5;
    int pin6;
    int pin7;
    int pin8;
};

#endif
